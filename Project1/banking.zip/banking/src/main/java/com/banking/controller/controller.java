package com.banking.controller;
import com.banking.model.*;

import java.io.IOException;
import java.util.regex.Pattern;

public class controller {
	
	public boolean Username(bank_model bk)  throws IOException
	{
		String username= bk.getAccount_Holder_Name();
		
		if(Pattern.matches("[A-Za-z]{4,15}", username))
		{
			return true;	
		}
		else {
			throw new IOException("username can only alphabets and digits ");
				}
		
	}
	
	
	public boolean Password(bank_model bk) throws IOException {
		String password= bk.getAccount_Password();
		
		if(Pattern.matches("[a-zA-Z0-9@#]{3,10}",password))
		{
			return true;	
		}
		else {
		      throw new IOException("try password again ");
		}
		
	}
	
	
	
	public boolean Deposit(bank_model bk,String pwd)throws IOException {
		String password=bk.getAccount_Password();
		if(pwd.equals(password)) {
		  int account_Balance =bk.getAccount_Balance();
		  System.out.println("account_Balance is : "+account_Balance);
		  return true;
		}
		else {
			
			 throw new IOException("wrong password");
		}
		
		}	
	

	
	public boolean Withdraw(bank_model bk,String pwd,int withdrawAmt) throws IOException {
		
		String password=bk.getAccount_Password();
		int account_Balance =bk.getAccount_Balance();
		  System.out.println("account_Balance is : "+account_Balance);
		  
			if(account_Balance>withdrawAmt) {
				
				return true;	
			}
		
		else {
			throw new IOException("not enough amount");
		}
		
	}
}

