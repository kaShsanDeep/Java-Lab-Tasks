package com.banking.model;
 
public class bank_model {

	private int  Account_number;
	private int Account_Balance;
	private String Account_Holder_Name;
	private String Account_Password;
	
	
	public int getAccount_number() {
		return Account_number;
	}
	public void setAccount_number(int account_number) {
		Account_number = account_number;
	}
	public int getAccount_Balance() {
		return Account_Balance;
	}
	public void setAccount_Balance(int account_Balance) {
		Account_Balance = account_Balance;
	}
	public String getAccount_Holder_Name() {
		return Account_Holder_Name;
	}
	public void setAccount_Holder_Name(String account_Holder_Name) {
		Account_Holder_Name = account_Holder_Name;
	}
	public String getAccount_Password() {
		return Account_Password;
	}
	public void setAccount_Password(String account_Password) {
		Account_Password = account_Password;
	}
	public void deposite(int account_Balance) {
		Account_Balance += account_Balance;
	}
	
	public void withdraw(int account_Balance) {
		Account_Balance -= account_Balance;
	}
	

}
