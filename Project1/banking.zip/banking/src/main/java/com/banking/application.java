package com.banking;
import com.banking.model.*;
import com.banking.controller.*;
import java.util.Scanner;
public class application {

	public static void main(String[] args) {
		
		//object creations
	Scanner obj  = new Scanner(System.in);
	controller sk = new controller();
	bank_model  bk = new bank_model();
	
	 
     
  	 try

  	 {
  		 System.out.println("Enter your Name");
  			 
  		     String Account_Holder_Name = obj.next();
  	
  		     Thread.sleep(1000);
  		     bk.setAccount_Holder_Name(Account_Holder_Name);
     
     
     	if(sk.Username(bk))
     	{
     		  System.out.println("Enter Password ");
     	        String account_Password= obj.next();
     	        bk.setAccount_Password(account_Password);
     	        Thread.sleep(1000);
     	        try {
     	        	
     	        		if(sk.Password(bk))
     	        		{
     	        			System.out.println("Enter account number ");
     	        	        int account_Number = obj.nextInt();
     	        	        
     	        	        bk.setAccount_number(account_Number);
     	        	        Thread.sleep(1000);
     	        	        
     	        	        System.out.println("Enter balance");
     	        	        int account_Balance=obj.nextInt();
     	        	        bk.setAccount_Balance(account_Balance);
     	        	        Thread.sleep(1000);
     	        	        
     	        	        
     	        	        
     	        	        int opr=0;
     	                    while(opr<3)
     	                        {
     	                          System.out.println("Select Operation" );
     	                          System.out.println("Press 1 for Deposit");
     	                          System.out.println("Press 2 for Withdraw");
     	                   
     	                    opr=obj.nextInt();
     	                   
     	                   
     	                   
     	  switch(opr) {
     	                    
     	        case 1:
     	                {
     	                    System.out.println("Enter password");
     	                    String paswd=obj.next();
     	                    System.out.println(" processing..... ");
     	                    	Thread.sleep(1000);
     	                    try {
     	                    	if(sk.Deposit(bk, paswd)) 
     	                    		Thread.sleep(1000);	
     	                    	 {
     	                    System.out.println(" Enter amount to deposit ");
     	                    	 int newAmt=obj.nextInt();
     	                    	 
     	                    	 bk.deposite(newAmt);
     	                    	System.out.println(" Deposite successfull ");
     	                    	Thread.sleep(1000);
     	                    System.out.println("  available account balance is :  "+bk.getAccount_Balance());
     	                   Thread.sleep(1000);
     	                   				}
     	                    			}
     	                    catch(Exception e)
     	                    			{
     	                    				System.out.println("ERROR");
     	                    				Thread.sleep(1000);
     	                    			}
     	                    
     	                    break;
     	                    
     	                    	
     	                }
     	                    
     	        case 2:
     	                    
     	                {

     	                    System.out.println("Enter password");
     	                    String paswd=obj.next();
     	                    System.out.println(" processing..... ");
     	                    	Thread.sleep(1000);
     	                    System.out.println("Enter amount to withdraw");
 	                    	int newAmt=obj.nextInt();
 	                    	try {
 	                    		if(sk.Withdraw(bk, paswd, newAmt)) 
 	                    			Thread.sleep(1000);
 	                    				{
 	                    				bk.withdraw(newAmt);
 	                    				System.out.println("Withdraw successfull");
 	                    				System.out.println("available account balance is :" +bk.getAccount_Balance());	
 	                    				Thread.sleep(1000);  
 	                    				}
 	                    					}
 	                    		
 	                    	catch(Exception e) 
 	                    			{
 	                    				System.out.println("please check \n **ERROR**");
 	                    				Thread.sleep(1000);
 	                    					}
 	                    				
     	                }
     	                       
     	                       
     	                
     	           					}
     	          }
     	       }
     	  	}
     	        	catch(Exception e) 
     	        			{
     	        			System.out.println("please check \n  **ERROR** ");
     	        			Thread.sleep(1000);
     	        						}
     					 }
     		}
	 				
	 
	 
	 
	 						catch(Exception e)
	 						{
	 					System.out.println("Wrongggg");
	 					
	 					System.exit(0);
	 						}
     obj.close();
          }


  }
	 
	 
	 
	 
	 
	