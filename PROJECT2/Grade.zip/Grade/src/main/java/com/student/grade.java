package com.student;
import java.util.Scanner;

public class grade {

     		public static void main(String args[]){

             try {
			Scanner sk= new Scanner(System.in);
         			System.out.println("Enter the name of the student");
         			Thread.sleep(1000);
			String Studentname = sk.next();
			Thread.sleep(1000);
			System.out.println("enter the roll_no of the student");
			
		        int roll_no = sk.nextInt();
		        Thread.sleep(1000);    
			System.out.println("marks of the student");
			
		        int marks = sk.nextInt(); 
            	cal  bc = new cal();
            	
            			
            bc.Username(Studentname);         
            bc.detailStudent(Studentname,roll_no,marks);
			bc.assigment(marks);    
			bc.detailStudent(marks);
			
		        
		        sk.close();
             }catch(Exception e) {}


			}
}
		     		