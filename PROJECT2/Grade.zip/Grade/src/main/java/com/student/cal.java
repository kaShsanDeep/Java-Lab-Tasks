package com.student;
import java.util.regex.Pattern;
import java.io.IOException;
	
	
	public class cal{	
			
		public boolean Username(String a) throws IOException
		{
			if(Pattern.matches("[a-zA-Z]{4,15}",a))
			{
				return true;	
			}
			
			else  {
				    throw new IOException("username can only alphabets ");
				
					}
		
		}
		
		
		public void detailStudent(String nam, int roll_no,int marks){
			if(marks<120) {
	 	System.out.println("**"+nam+" scored " +marks+" marks **");
		}
		else 
		{ System.out.println("********this is not valid marks***********");}
		}
	      
		
		
		
		public int detailStudent(int marks){
	     	try {
	        	if(marks<=40)
	                   {
	                     System.out.println("you're failed");
	                     Thread.sleep(1000);
	                     
	                      }
	         else if(marks>=41&&marks<=50)
	                      {
	                      System.out.println("\n -----you've got D grade-----");
	                      Thread.sleep(1000);
	                       }
	         else if(marks>=51&&marks<=60)
	                            {
	                      System.out.println("\n------you've got C grade------");
	                      Thread.sleep(1000);
	                       }
	         else if(marks>=61&&marks<=70)
	                        {
	                      System.out.println("-------you've got C+ grade------");
	                      Thread.sleep(1000);
	                        }
	         else if(marks>=71&&marks<=80)
	                        {
	                      System.out.println("-------you've got B grade-------");
	                      Thread.sleep(1000);
	                        }
	          else if(marks>=81&&marks<=90)
	                        {
	                      System.out.println("-------you've got B+ grade------");
	                      Thread.sleep(1000);
	                        }
	          else if(marks>=91&&marks<=100)
	                        {
	                      System.out.println("--------you've got A+ grade------");
	                      Thread.sleep(1000);
	                        }
	 
	          else{
	             System.out.println("****this is invalid*****");
	             Thread.sleep(1000);
	                }
	     	}catch(Exception e) {}
	     		
	     	
	        	
	          return marks;
	          
	          
		}
	          
	        
	        public int assigment(int marks) {
	        
	        	int a=0;
	        	int b=0;
	   
	        	if (marks<=40) {
	        		     a+=5;
	        		     b= a+marks;
	        	        }
	        	 else if(marks<=60){
	        			  a+=10;
	        	          b=a+marks;	 
	        	 }
	        	 else if(marks<=80) {
	        		 a+=15;
	        		 b=a+marks;
	        	 }
	        	 else if(marks<=100) {
	        		 a+=20;
	        		 b=a+marks;
	        	 }
	        
	        else {
	        	System.out.println("assigmnt marks are not valid");
	        	  
	        }
	        		 
	        	 try {
	        		 if(marks<120) {
	        	System.out.println( "Assigment: " +a+ "\nTest marks : " +marks);
	        	Thread.sleep(1000);
	        		 }
	        	System.out.println("Total marks are : "+b);
	        	Thread.sleep(1000);
	        	 }catch(Exception e) {}
	        	return b;
	        	
	        }
	        
	        
	        
	        
	        }
